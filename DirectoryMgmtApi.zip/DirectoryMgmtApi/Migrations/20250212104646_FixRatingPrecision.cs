﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DirectoryMgmtApi.Migrations
{
    /// <inheritdoc />
    public partial class FixRatingPrecision : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Businesses_Categories_CategoryID",
                table: "Businesses");

            migrationBuilder.DropForeignKey(
                name: "FK_Businesses_Categories_CategoryId",
                table: "Businesses");

            migrationBuilder.DropIndex(
                name: "IX_Businesses_CategoryID",
                table: "Businesses");

            migrationBuilder.DropColumn(
                name: "CategoryID",
                table: "Businesses");

            migrationBuilder.RenameColumn(
                name: "CategoryId",
                table: "Businesses",
                newName: "CategoryID");

            migrationBuilder.RenameIndex(
                name: "IX_Businesses_CategoryId",
                table: "Businesses",
                newName: "IX_Businesses_CategoryID");

            migrationBuilder.AlterColumn<decimal>(
                name: "Rating",
                table: "Businesses",
                type: "decimal(18,2)",
                nullable: true,
                oldClrType: typeof(decimal),
                oldType: "decimal(18,2)");

            migrationBuilder.AddForeignKey(
                name: "FK_Businesses_Categories_CategoryID",
                table: "Businesses",
                column: "CategoryID",
                principalTable: "Categories",
                principalColumn: "CategoryID",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Businesses_Categories_CategoryID",
                table: "Businesses");

            migrationBuilder.RenameColumn(
                name: "CategoryID",
                table: "Businesses",
                newName: "CategoryId");

            migrationBuilder.RenameIndex(
                name: "IX_Businesses_CategoryID",
                table: "Businesses",
                newName: "IX_Businesses_CategoryId");

            migrationBuilder.AlterColumn<decimal>(
                name: "Rating",
                table: "Businesses",
                type: "decimal(18,2)",
                nullable: false,
                defaultValue: 0m,
                oldClrType: typeof(decimal),
                oldType: "decimal(18,2)",
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "CategoryID",
                table: "Businesses",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Businesses_CategoryID",
                table: "Businesses",
                column: "CategoryID");

            migrationBuilder.AddForeignKey(
                name: "FK_Businesses_Categories_CategoryID",
                table: "Businesses",
                column: "CategoryID",
                principalTable: "Categories",
                principalColumn: "CategoryID");

            migrationBuilder.AddForeignKey(
                name: "FK_Businesses_Categories_CategoryId",
                table: "Businesses",
                column: "CategoryId",
                principalTable: "Categories",
                principalColumn: "CategoryID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
