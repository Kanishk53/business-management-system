using DirectoryMgmtApi.Models;
using DirectoryMgmtApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace DirectoryMgmtApi.Controllers
{
    [Route("api/businesses")]
    [ApiController]
    public class BusinessesController : ControllerBase
    {
        private readonly BusinessService _businessService;

        public BusinessesController(BusinessService businessService)
        {
            _businessService = businessService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _businessService.GetAllBusinessesAsync());
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var business = await _businessService.GetBusinessByIdAsync(id);
            if (business == null) return NotFound("Business not found.");
            return Ok(business);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Business business)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var success = await _businessService.AddBusinessAsync(business);
            if (!success)
                return BadRequest("Invalid Category ID.");

            return CreatedAtAction(nameof(GetById), new { id = business.BusinessID }, business);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Business business)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var updated = await _businessService.UpdateBusinessAsync(id, business);
            if (!updated) return NotFound("Business not found.");

            return NoContent();
        }

//         [HttpDelete("{id}")]
//         public async Task<IActionResult> Delete(int id)
//         {
//             var deleted = await _businessService.DeleteBusinessAsync(id);
//             if (!deleted) return NotFound("Business not found.");

//             return NoContent();
//         }
//     }
// }

[HttpDelete("{id:int}")]
public async Task<IActionResult> Delete(int id)
{
    if (id <= 0) return BadRequest("Invalid Business ID.");

    var deleted = await _businessService.DeleteBusinessAsync(id);
    if (!deleted) return NotFound("Business not found.");

    return NoContent();
}}}
