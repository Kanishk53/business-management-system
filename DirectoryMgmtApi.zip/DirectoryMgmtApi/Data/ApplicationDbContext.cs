using Microsoft.EntityFrameworkCore;
using DirectoryMgmtApi.Models;

namespace DirectoryMgmtApi.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Business> Businesses { get; set; }
        public DbSet<Category> Categories { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Business>()
                .HasIndex(b => b.PhoneNumber)
                .IsUnique();

            modelBuilder.Entity<Business>()
                .Property(b => b.CreatedAt)
                .HasDefaultValueSql("GETDATE()");

            modelBuilder.Entity<Business>()
                .Property(b => b.UpdatedAt)
                .HasDefaultValueSql("GETDATE()");

            modelBuilder.Entity<Business>()
                .HasOne(b => b.Category)
                .WithMany()
                .HasForeignKey(b => b.CategoryID)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
