using System.ComponentModel.DataAnnotations;

namespace DirectoryMgmtApi.Models
{
    public class Category
    {
        [Key]
        public int CategoryID { get; set; }

        [Required, MaxLength(100)]
        public string Name { get; set; } = string.Empty;
    }
}
