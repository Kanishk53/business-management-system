using DirectoryMgmtApi.Data;
using DirectoryMgmtApi.Models;
using Microsoft.EntityFrameworkCore;

namespace DirectoryMgmtApi.Services
{
    public class BusinessService
    {
        private readonly ApplicationDbContext _context;

        public BusinessService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<List<Business>> GetAllBusinessesAsync()
        {
            return await _context.Businesses
                .Include(b => b.Category)
                .AsNoTracking()
                .ToListAsync();
        }

        public async Task<Business?> GetBusinessByIdAsync(int id)
        {
            return await _context.Businesses
                .Include(b => b.Category)
                .AsNoTracking()
                .FirstOrDefaultAsync(b => b.BusinessID == id);
        }

        public async Task<bool> AddBusinessAsync(Business business)
        {
            var categoryExists = await _context.Categories.AnyAsync(c => c.CategoryID == business.CategoryID);
            if (!categoryExists) return false;

            _context.Businesses.Add(business);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdateBusinessAsync(int id, Business business)
        {
            var existingBusiness = await _context.Businesses.FindAsync(id);
            if (existingBusiness == null) return false;

            existingBusiness.Name = business.Name;
            existingBusiness.Address = business.Address;
            existingBusiness.City = business.City;
            existingBusiness.State = business.State;
            existingBusiness.ZipCode = business.ZipCode;
            existingBusiness.PhoneNumber = business.PhoneNumber;
            existingBusiness.Website = business.Website;
            existingBusiness.Rating = business.Rating;
            existingBusiness.CategoryID = business.CategoryID;
            existingBusiness.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteBusinessAsync(int id)
        {
            var business = await _context.Businesses.FindAsync(id);
            if (business == null) return false;

            _context.Businesses.Remove(business);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
