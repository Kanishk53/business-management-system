using DirectoryMgmtApi.Data;
using DirectoryMgmtApi.Services;
using Microsoft.EntityFrameworkCore;
using System.Net;

var builder = WebApplication.CreateBuilder(args);

// Load Configuration
var configuration = builder.Configuration;

// Configure Database Connection
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(configuration.GetConnectionString("DefaultConnection"))
           .UseLazyLoadingProxies());

builder.Services.AddScoped<BusinessService>();
builder.Services.AddScoped<CategoryService>();

// Configure CORS Policy
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll",
        policy =>
        {
            policy.WithOrigins("http://localhost:5173")
                  .AllowAnyHeader()
                  .AllowAnyMethod();
        });
});

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddLogging();

// builder.WebHost.ConfigureKestrel(options =>
// {
//     var kestrelConfig = configuration.GetSection("Kestrel:Endpoints:Http:Url").Value;
//     if (!string.IsNullOrEmpty(kestrelConfig))
//     {
//         options.Listen(IPAddress.Loopback, new Uri(kestrelConfig).Port);
//     }
// });

builder.WebHost.UseUrls("http://127.0.0.1:5005");


var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("AllowAll");
app.UseRouting();
app.UseAuthorization();
app.MapControllers();
app.Run();
