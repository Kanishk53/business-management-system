import React from "react";
import Home from "./pages/Home";
import { BrowserRouter, Routes,Route } from 'react-router-dom';
import Business from "./pages/Business"
import Aboutus from "./pages/Aboutus";
import Ourteam from "./pages/Ourteam";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const App = () => {
  return (
    <div >
      <ToastContainer 
        position="top-right"
        autoClose={3000}
        hideProgressBar={false}
        closeOnClick
        pauseOnHover
        draggable
      />
       <BrowserRouter>
             <Routes>
                    <Route path='/' element={<Home></Home> }></Route>  
                    <Route path='/businesses' element={<Business></Business> }></Route> 
                    <Route path='/team' element={<Ourteam></Ourteam> }></Route>
                    <Route path='/about' element={<Aboutus></Aboutus> }></Route>
                    </Routes></BrowserRouter>
   
    </div>
  );
};

export default App;
