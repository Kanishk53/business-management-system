import axios from "axios";

const API_BASE_URL = import.meta.env.VITE_BASE_URL.trim();
const BASE_URL = API_BASE_URL.endsWith("/") ? API_BASE_URL.slice(0, -1) : API_BASE_URL;

// Businesses API
export const getAllBusinesses = () => axios.get(`${BASE_URL}/api/businesses`);
export const getBusinessById = (id) => axios.get(`${BASE_URL}/api/businesses/${id}`);
export const createBusiness = (business) => axios.post(`${BASE_URL}/api/businesses`, business);
export const updateBusiness = (id, business) => axios.put(`${BASE_URL}/api/businesses/${id}`, business);
export const deleteBusiness = (id) => axios.delete(`${BASE_URL}/api/businesses/${id}`);

// Categories API
export const getAllCategories = () => axios.get(`${BASE_URL}/api/categories`);
export const getCategoryById = (id) => axios.get(`${BASE_URL}/api/categories/${id}`);
export const createCategory = (category) => axios.post(`${BASE_URL}/api/categories`, category);
export const updateCategory = (id, category) => axios.put(`${BASE_URL}/api/categories/${id}`, category);
export const deleteCategory = (id) => axios.delete(`${BASE_URL}/api/categories/${id}`);
