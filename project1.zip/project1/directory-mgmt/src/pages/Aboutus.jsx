import React, { useState } from 'react'
import Navbar from '../components/Navbar'
import Leftbar from '../components/Leftbar'
import { RxCrossCircled } from "react-icons/rx";

const Aboutus = () => {
    const [isOpen, setIsOpen] = useState(false);


    const handleSubmit = (e) => {
        e.preventDefault();
        console.log("Form Submitted", formData);
        setIsOpen(false);
    };

    return (
        <div className='overflow-hidden h-[100vh]'>
        <div className='flex'>
      <Navbar/>
      <Leftbar/>
      </div>
  
            <div className=' mt-20 ml-36  '>

                <div className=' flex flex-col items-center overflow-x-hidden'>
                    <p className=' mt-7  text-4xl  text-center border-inherit  rounded-md font-bold font-sans'>About BDO </p>
                    <p className="text-center ml-20 mr-5  p-4 text-lg">
                        We are a leading professional services firm offering Tax, Assurance, Accounting, Outsourcing, Advisory and Technology-led Services for both domestic and international clients across a range of industries. Bringing innovative thinking to a digitally evolving market is helping us reinstate and better offer our long-standing promise of delivering quality driven by value and up-to-date thinking.
                    </p>

                  
                    <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 ml-20 gap-4">
                        <div className="bg-white p-6 shadow-lg rounded-lg">
                            <h3 className="text-xl font-semibold mb-2">🔍 Transparency</h3>
                            <p className="text-gray-600">We believe in open communication and honesty in all our dealings.</p>
                        </div>

                        <div className="bg-white p-6 shadow-lg rounded-lg">
                            <h3 className="text-xl font-semibold mb-2">🚀 Innovation</h3>
                            <p className="text-gray-600">Our team constantly works to improve and deliver cutting-edge solutions.</p>
                        </div>

                        <div className="bg-white p-6 shadow-lg rounded-lg mr-5">
                            <h3 className="text-xl font-semibold mb-2">🤝 Customer Focus</h3>
                            <p className="text-gray-600">We prioritize customer satisfaction by delivering reliable services.</p>
                        </div>
                    </div>

                    <div className="mt-10 text-center">
                        <h3 className="text-2xl font-bold">Get in Touch</h3>
                        <p className="text-gray-600">Have questions? </p>
                        <button
                            onClick={() => setIsOpen(true)}
                            className="bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition"
                        >
                            Contact Us
                        </button>

                        {isOpen && (
                            <div className=" backdrop-blur-sm fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
                                <div className="bg-gray-300 mt-8 p-4  items-center  rounded-lg shadow-lg w-96">

                                    <div className='justify-between flex'>
                                    <h2 className="text-center text-2xl font-bold mb-4">Contact Us</h2>
                                    <RxCrossCircled className='hover:cursor-pointer text-3xl' onClick={() => setIsOpen(false)}/></div>

                                    <div className="grid grid-cols-3  items-center">
                                        <label className= "flex text-xl mb-2  " >Name <span className='text-red-500 text-[18px] font-bold'>*</span></label>
                                        <input
                                            type="text" placeholder='John Doe'
                                            className=" col-span-2  shadow-md mb-2  border bg-gray-200 rounded-md px-2 py-1  focus:outline-none" required
                                        />
                                    </div>
                                    <div className="grid grid-cols-3  items-center">
                                        <label className=" flex text-xl mb-2  " >Email <span className='text-red-500 text-[18px] font-bold'>*</span></label>
                                        <input
                                            type="email" placeholder='xyz@example.com'
                                            className=" col-span-2  shadow-md mb-2  border bg-gray-200 rounded-md px-2 py-1 focus:outline-none" required
                                        />
                                    </div>
                                    <div className="grid grid-cols-3  items-center">
                                        <label className=" flex text-xl mb-2 " >Address <span className='text-red-500 text-[18px] font-bold'>*</span></label>
                                        <textarea
                                            type="text" placeholder='Green Street'
                                            className="col-span-2  shadow-md mb-2  border bg-gray-200 rounded-md px-2 py-1 focus:outline-none" required
                                        />
                                    </div>
                                    <div className="grid grid-cols-3  items-center">
                                        <label className="flex text-xl mb-2 py-1" >City/State <span className='text-red-500 text-[18px] font-bold'>*</span></label>
                                        <input placeholder='New York'
                                            type="text"
                                            className="col-span-2  shadow-md   border bg-gray-200 rounded-md px-2 py-1 mb-2 focus:outline-none" required
                                        />
                                    </div>
                                    <div className="grid grid-cols-3  items-center">
                                        <label className="flex text-xl mb-2 py-1" >Postal Code <span className='text-red-500 text-[18px] font-bold'>*</span></label>
                                        <input placeholder='123456'
                                            type="tel"           
                                            className="col-span-2  shadow-md   border bg-gray-200 rounded-md px-2 py-1 mb-2 focus:outline-none" required
                                        />
                                    </div>
                                    <div className="grid grid-cols-3  items-center">
                                        <label className="flex text-xl mb-2 py-1" >Company <span className='text-red-500 text-[18px] font-bold'>*</span></label>
                                        <input placeholder='New York'
                                            type="text"
                                            className="col-span-2  shadow-md   border bg-gray-200 rounded-md px-2 py-1 mb-2 focus:outline-none" required
                                        />
                                    </div>
                                    


                                    <button className="bg-green-500 text-black font-semibold px-4 py-2 rounded mt-4 hover:bg-green-600 transition" onClick={handleSubmit}>
                                        Submit
                                    </button>

                                </div>
                            </div>
                        )}
                    </div>
                </div>
                </div>
            </div>
    )
}

export default Aboutus
