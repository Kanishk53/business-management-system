import React, { useState, useEffect, useMemo } from 'react'
import Navbar from '../components/Navbar'
import Leftbar from '../components/Leftbar'
import { FaEdit } from 'react-icons/fa'
import { IoTrashBin } from 'react-icons/io5';
import { RxCrossCircled } from 'react-icons/rx';
import EditBusinessModal from "./EditBusinessModal"
import { getAllBusinesses, createBusiness, getAllCategories, deleteBusiness } from '../services/api';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


const Business = () => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [showPopUp, setPopup] = useState(false)
    const [isBlurred, setIsBlurred] = useState(false);
    const [businesses, setBusinesses] = useState([]);
    const [categories, setCategories] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedBusinessID, setSelectedBusinessID] = useState(null);
    const [selectedCategoryID, setSelectedCategoryID] = useState(null);
    const [isEditModalOpen, setEditModalOpen] = useState(false);
    const [sortConfig, setSortConfig] = useState({ key: "name", direction: "asc" });

    const [newBusiness, setNewBusiness] = useState({
        name: '',
        categoryID: '',
        address: '',
        city: '',
        state: '',
        zipCode: '',
        phoneNumber: '',
        website: '',
        rating: ''
    });

    useEffect(() => {
        fetchBusinesses();
        fetchCategories();
    }, []);

    const fetchBusinesses = async () => {
        try {
            const response = await getAllBusinesses();
            setBusinesses(response.data);
            console.log("Businesses Array:",response);

        } catch (error) {
            console.error('Error fetching businesses:', error);
        }
    };

    const fetchCategories = async () => {
        try {
            const response = await getAllCategories();
            setCategories(response.data);
        } catch (error) {
            console.error('Error fetching categories:', error);
        }
    };

    const filteredBusinesses = useMemo(() => {
        return businesses.filter(business =>
            business.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            business.city.toLowerCase().includes(searchQuery.toLowerCase())
        );
    }, [businesses, searchQuery]);
    

    // Sorting Logic
    const sortedBusinesses = useMemo(() => {
        if (!sortConfig.key) return filteredBusinesses;

        return [...filteredBusinesses].sort((a, b) => {
            const valA = a[sortConfig.key];
            const valB = b[sortConfig.key];

            if (typeof valA === "string") {
                return sortConfig.direction === "asc"
                    ? valA.localeCompare(valB)
                    : valB.localeCompare(valA);
            } else {
                return sortConfig.direction === "asc" ? valA - valB : valB - valA;
            }
        });
    }, [filteredBusinesses, sortConfig]);

    // Function to Handle Sorting
    const handleSort = (key) => {
        setSortConfig((prev) => ({
            key,
            direction: prev.key === key && prev.direction === "asc" ? "desc" : "asc",
        }));
    };
    const getSortIcon = (key) => {
        if (sortConfig.key !== key) return "⬍"; // Default unsorted icon
        return sortConfig.direction === "asc" ? "🔼" : "🔽";
    };

   
    
    const openEditModal = (BusinessID, categoryID) => {
        setSelectedBusinessID(BusinessID);
        setSelectedCategoryID(categoryID);
        setEditModalOpen(true);

    };
    const closeEditModal = () => {
        setEditModalOpen(false);
    };

    const handleAddBusiness = async () => {
        try {
            await createBusiness(newBusiness);
            fetchBusinesses();
            setIsModalOpen(false);
            setIsBlurred(false);
            setNewBusiness({
                name: '',
                categoryID: '',
                address: '',
                city: '',
                state: '',
                zipCode: '',
                phoneNumber: '',
                website: '',
                rating: ''
            });
            toast.success("Business added successfully!");
        } catch (error) {
            console.error('Error creating business:', error);
            toast.error("Failed to add business. Please try again.");
        }
    };

    const handleDelete = async (businessID) => {
        if (!businessID || businessID <= 0) {
            console.error("Invalid Business ID. Cannot delete.");
            return;
        }
    
        try {
            await deleteBusiness(businessID);
            setBusinesses(businesses.filter(business => business.businessID !== businessID));
            setPopup(false);
            toast.success("Business deleted successfully!");
        } catch (error) {
            toast.error("Failed to delete business. Please try again.");
            console.error("Error deleting business:", error.message);
        }
    };
    
    const handleIconClick = () => {
        setIsModalOpen(true);
        setIsBlurred(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setIsBlurred(false);
    };



    function popUp() {
        return (
            <div className='w-[250px] h-[150px] absolute bottom-2 right-20 bg-gray-100 border-inherit rounded-md p-3'>
                <p>Are you sure you want to <span className='text-red-500'>delete</span> this business?</p>
                <button 
    type="button" 
    className='border-inherit text-white rounded-md bg-gray-500 hover:bg-gray-400 py-1 text-md w-10 ml-0 m-3' 
    onClick={() => {
        handleDelete(selectedBusinessID);
        setPopup(false);
    }}
>
    Ok
</button>

                <button 
                    type="button" 
                    className='border-inherit text-white rounded-md bg-gray-500 hover:bg-gray-400 py-1 text-md w-20 m-3' 
                    onClick={() => setPopup(false)} 
                >
                    Cancel
                </button>
            </div>
        );
    }
    
    return (
        <div className={` ${isBlurred ? "backdrop-blur-4xl" : ""}`}>
              <ToastContainer 
                            position="top-right"
                            autoClose={3000}
                            hideProgressBar={false}
                            closeOnClick
                            pauseOnHover
                            draggable      />

            <div className='flex'>
                <Navbar />
                <Leftbar />
            </div>

            <div className=' mt-28  ml-56 w-[80%]  '>


                <div className="flex items-center w-full relative">
                    <span className="text-4xl font-bold font-sans ml-[40%]">Businesses</span>
                    <input
                        type="text"
                        placeholder="Search by Business Name or City..."
                        className="w-50 truncate p-1 mx-20 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                    <p className='hover:cursor-pointer text-xs font-semibold' onClick={handleIconClick}>+ Add business</p>
                </div>

                <div className={`h-[70vh] overflow-y-auto thin-scrollbar`}>
                    <table className=' mt-5  border-collapse border '>

                        <thead className='text-white bg-gray-500 border-gray-500  w-[100%]'>
                            <tr className=''>
                                {/* <td width='250' className=' px-4 py-2 border'>Business ID</td> */}
                                <td width='100' className=' px-4 py-2 border'
                                >
                                    Name
                                    <span className="cursor-pointer" onClick={() => handleSort("name")}>
                                        {getSortIcon("name")}
                                    </span>
                                </td>
                                <td width='100' className=' px-4 py-2 text-center border'>Category</td>
                                <td width='300' className='px-4 py-2 border text-center'>Street Address</td>
                                <td width='100' className=' px-4 py-2 border'
                                >
                                   City
                                    <span className="cursor-pointer" onClick={() => handleSort("city")}>
                                        {getSortIcon("city")}
                                    </span>
                                </td>
                                <td width='100' className=' px-4 py-2 text-center border'>State/Zip</td>
                                <td width='200' className='px-4 py-2 text-center border'>Contact Number</td>
                                <td width='200' className='px-4 py-2 text-center border'>Website</td>
                                <td className='px-4 py-2 text-center border'>Rating</td>
                                <td className='px-4 py-2 text-center border'>Action</td>
                            </tr>
                        </thead>
                        <tbody className=' '>
                            {sortedBusinesses.map((business) => (
                                <tr key={business.BusinessID}>
                                    {/* <td className='px-2 py-2 border'>{business.BusinessID}</td> */}
                                    <td className='px-2 py-2 border'>{business.name}</td>
                                    <td className='px-2 py-2 border'>{categories.find(cat => cat.categoryID === business.categoryID)?.name || 'N/A'}</td>
                                    <td className='px-2 py-2 border'>{business.address}</td>
                                    <td className='px-2 py-2 border'>{business.city}</td>
                                    <td className='px-2 py-2 border'>{business.state}, {business.zipCode}</td>
                                    <td className='px-2 py-2 border'>{business.phoneNumber}</td>
                                    <td className='px-2 py-2 border'>{business.website}</td>
                                    <td className='px-2 py-2 border'>{business.rating}</td>
                                    <td className='px-3 flex justify-between py-6 border'>  <FaEdit className="text-lg cursor-pointer"
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            console.log("Opening Edit Modal for:", business.businessID);
                                            openEditModal(business.businessID, business.categoryID);
                                        }}
                                    />
                                 <IoTrashBin 
    className='text-lg text-red-700 cursor-pointer' 
    onClick={() => { setSelectedBusinessID(business.businessID); setPopup(true); }} 
/>



                                        {showPopUp && popUp()
                                        }</td>
                                </tr>))}
                        </tbody>
                    </table>
                </div>

                {isModalOpen && (
                    <div className=" backdrop-blur-sm fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
                        <div className="bg-gray-300 mt-20 px-4 py-2 w-2/5  items-center  rounded-lg shadow-lg ">

                            <div className='justify-between flex'>
                                <h2 className="text-center text-xl font-bold mb-4">Add new Business</h2>
                                <RxCrossCircled className='hover:cursor-pointer text-3xl' onClick={handleCloseModal} /></div>

                            <div className="grid grid-cols-3  items-center">
                                <label className="flex  mb-2  text-xl" >Business Name <span className='text-red-500 text-[18px] font-bold'>*</span></label>
                                <input
                                    type="text" placeholder='xyz'
                                    className=" col-span-2  shadow-md mb-2  border bg-gray-200 rounded-md px-2  focus:outline-none" value={newBusiness.name} onChange={(e) => setNewBusiness({ ...newBusiness, name: e.target.value })} required
                                />
                            </div>
                            <div className="grid grid-cols-3  items-center">
                                <label className=" flex  mb-1 text-xl " >Category <span className='text-red-500 text-[18px] font-bold'>*</span></label>
                                <select className='col-span-2  shadow-md mb-2  border bg-gray-200 rounded-md px-2  focus:outline-none' value={newBusiness.categoryID}
                                    onChange={(e) => setNewBusiness({ ...newBusiness, categoryID: e.target.value })}>
                                    <option value=''>Select a category</option>
                                    {categories.map(category => (
                                        <option key={category.categoryID} value={category.categoryID}>
                                            {category.name}
                                        </option>
                                    ))
                                    }
                                </select>
                            </div>
                            <div className="grid grid-cols-3  items-center">
                                <label className=" flex  mb-1 text-xl" >Street Address <span className='text-red-500 text-[18px] font-bold'>*</span></label>
                                <textarea
                                    type="text" placeholder='Green Street'
                                    className="col-span-2  shadow-md mb-2  border bg-gray-200 rounded-md px-2 focus:outline-none" value={newBusiness.address}
                                    onChange={(e) => setNewBusiness({ ...newBusiness, address: e.target.value })}
                                    required
                                />
                            </div>
                            <div className="grid grid-cols-3  items-center">
                                <label className="flex  mb-1 text-xl" >City <span className='text-red-500 text-[18px] font-bold'>*</span></label>
                                <input placeholder='New Delhi'
                                    type="text"
                                    className="col-span-2  shadow-md   border bg-gray-200 rounded-md px-2  mb-2 focus:outline-none" value={newBusiness.city}
                                    onChange={(e) => setNewBusiness({ ...newBusiness, city: e.target.value })}
                                    required
                                />
                            </div>
                            <div className="grid grid-cols-3  items-center">
                                <label className="flex mb-1 text-xl" >State <span className='text-red-500 text-[18px] font-bold'>*</span></label>
                                <input placeholder='India'
                                    type="text"
                                    className="col-span-2  shadow-md   border bg-gray-200 rounded-md px-2 mb-2 focus:outline-none" value={newBusiness.state}
                                    onChange={(e) => setNewBusiness({ ...newBusiness, state: e.target.value })}
                                    required
                                />
                            </div>
                            <div className="grid grid-cols-3  items-center">
                                <label className="flex  mb-1 text-xl" >Zip Code <span className='text-red-500 text-[18px] font-bold'>*</span></label>
                                <input placeholder='123456'
                                    type="tel" maxLength={6}
                                    className="col-span-2  shadow-md   border bg-gray-200 rounded-md px-2 mb-2 focus:outline-none" value={newBusiness.zipCode}
                                    onChange={(e) => setNewBusiness({ ...newBusiness, zipCode: e.target.value })}
                                    required
                                />
                            </div>
                            <div className="grid grid-cols-3  items-center">
                                <label className="flex mb-1 text-xl" >Phone Number <span className='text-red-500 text-[18px] font-bold'>*</span></label>
                                <input
                                    type="tel" pattern="[6-9]{1}[0-9]{9}" placeholder="+91 XXXXX XXXXX" required className="col-span-2  shadow-md   border bg-gray-200 rounded-md px-2 mb-2 focus:outline-none" value={newBusiness.phoneNumber}
                                    onChange={(e) => setNewBusiness({ ...newBusiness, phoneNumber: e.target.value })}
                                />
                            </div>
                            <div className="grid grid-cols-3  items-center">
                                <label className="flex mb-1 text-xl" >Website </label>
                                <input placeholder='https://example.com'
                                    type="url"
                                    className="col-span-2  shadow-md   border bg-gray-200 rounded-md px-2 mb-2 focus:outline-none" value={newBusiness.website}
                                    onChange={(e) => setNewBusiness({ ...newBusiness, website: e.target.value })}

                                />
                            </div>
                            <div className="grid grid-cols-3  items-center">
                                <label for="rating" className="flex mb-1 text-xl" >Rating</label>

                                <input
                                    type="number"
                                    min="0"
                                    max="5"
                                    step="0.1"
                                    placeholder="0 - 5"
                                    className="col-span-2 shadow-md border bg-gray-200 rounded-md px-2 mb-2 focus:outline-none"
                                    value={newBusiness.rating}
                                    onChange={(e) => {
                                        let value = parseFloat(e.target.value);
                                        if (value < 0) value = 0;
                                        if (value > 5) value = 5;
                                        setNewBusiness({ ...newBusiness, rating: value });
                                    }}
                                />

                            </div>


                            <button className="bg-green-600 items-center text-black font-semibold px-4 py-1 rounded-lg mt-4 hover:bg-green-800 hover:text-white transition" onClick={handleAddBusiness}>
                                Submit
                            </button>

                        </div>


                    </div>
                )}


                {isEditModalOpen && (
                    <div className="backdrop-blur-sm fixed inset-0 flex items-center justify-center bg-opacity-50">
                        <EditBusinessModal
                            businessID={selectedBusinessID}
                            categoryID={selectedCategoryID}
                            isOpen={isEditModalOpen}
                            onClose={()=>{closeEditModal();  fetchBusinesses()}}
                        />
                    </div>)}

            </div>

        </div>

    )
}

export default Business
