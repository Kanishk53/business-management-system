import React, { useState } from "react";
import Navbar from "../components/Navbar";
import Leftbar from "../components/Leftbar";
import { format, startOfMonth, endOfMonth, startOfWeek, endOfWeek, addDays, isSameMonth, isSameDay, addMonths, subMonths } from "date-fns";


const Home = () => {
    const [currentMonth, setCurrentMonth] = useState(new Date());
    const today = new Date();

    const getHeader = () => {
        return (
            <div className="flex justify-between items-center py-2">
                <button onClick={() => setCurrentMonth(subMonths(currentMonth, 1))} className="px-1 py-1 bg-gray-200 hover:bg-gray-300 rounded">◀</button>
                <h2 className="text-xl font-bold">{format(currentMonth, "MMMM yyyy")}</h2>
                <button onClick={() => setCurrentMonth(addMonths(currentMonth, 1))} className="px-1 py-1 bg-gray-200 hover:bg-gray-300 rounded">▶</button>
            </div>
        );
    };

    const getDaysOfWeek = () => {
        const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
        return (
            <div className="grid grid-cols-7 text-center font-bold">
                {days.map(day => (
                    <div key={day} className="py-1">{day}</div>
                ))}
            </div>
        );
    };

    const getDays = () => {
        const startMonth = startOfMonth(currentMonth);
        const endMonth = endOfMonth(currentMonth);
        const startDate = startOfWeek(startMonth);
        const endDate = endOfWeek(endMonth);

        let date = startDate;
        const days = [];

        while (date <= endDate) {
            days.push(date);
            date = addDays(date, 1);
        }

        return (
            <div className="grid grid-cols-7 text-center">
                {days.map(day => (
                    <div
                        key={day}
                        className={`p-2 border cursor-pointer transition-all
                        ${isSameMonth(day, currentMonth) ? "text-black" : "text-gray-400"}
                        ${isSameDay(day, today) ? "bg-blue-700 text-white " : "hover:bg-gray-300"}`}
                    >
                        {format(day, "d")}
                    </div>
                ))}
            </div>
        );
    };


    return (
        <div className='overflow-hidden h-[100vh]'>
        <div className='flex'>
      <Navbar/>
      <Leftbar/>
      </div>
  
            <div className=' mt-20 ml-36  '>

                <div className=' flex flex-col items-center overflow-x-hidden'>
                    <p className=' mt-7  text-4xl  text-center border-inherit  rounded-md font-bold font-sans'>Welcome to Directory Management System of BDO</p>
                        <p className=' text-center text-gray-500 mt-[10px]'>Driven to be the best. Global solutions.</p>
                    </div>


</div>
<div className="flex mt-2 space-x-3 absolute right-10">
                    <button className="px-4 py-1 bg-blue-700 text-white rounded-3xl hover:bg-blue-500">
                        Add Event
                    </button>
                    <button className="px-4 py-1 bg-blue-700 text-white rounded-3xl hover:bg-blue-500">
                        Schedule a meeting
                    </button>
                </div>
<div className="w-[80%] ml-56 mt-14 bg-gray-100 shadow-lg p-3 rounded-lg">
            {getHeader()}
            {getDaysOfWeek()}
            {getDays()}
        </div>
        </div>
    );
};

export default Home;

