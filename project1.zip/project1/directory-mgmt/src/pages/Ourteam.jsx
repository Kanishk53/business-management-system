import React from 'react'
import Navbar from '../components/Navbar'
import Leftbar from '../components/Leftbar'
import { FaUserCircle } from "react-icons/fa";

const Ourteam = () => {
  return (
    <div className='overflow-hidden h-[100vh]'>
    <div className='flex'>
  <Navbar/>
  <Leftbar/>
  </div>

        <div className=' mt-20 ml-36  w-[100%] '>

        <div className=' flex flex-col items-center overflow-x-hidden'>
        <p className=' mt-7  text-4xl -ml-32 text-center border-inherit  rounded-md font-bold font-sans'>Our Team</p>
                </div>
     
      <div className="ml-28 grid grid-cols-1 mt-5 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-5 mr-48">
          {Array.from({ length: 10 }).map((_, index) => (
            <div key={index} className="bg-gray-100 shadow-md rounded-lg p-4 flex flex-col items-center">
              <FaUserCircle className="text-gray-400" size={100} />
              <h3 className="font-bold text-lg mt-2">Name</h3>
              <p className="text-gray-600 text-sm">(Designation)</p>
            </div>
          ))}
        </div>
        </div>
</div>
  )
}

export default Ourteam
