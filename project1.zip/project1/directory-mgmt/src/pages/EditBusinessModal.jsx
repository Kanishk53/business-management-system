import React, { useState, useEffect } from 'react';
import { RxCrossCircled } from 'react-icons/rx';
import { updateBusiness, getBusinessById, getAllCategories } from '../services/api';
import {  toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


const EditBusinessModal = ({ businessID,  isOpen, onClose }) => {


    const [business, setBusiness] = useState({
        name: '',
        categoryID: '',
        address: '',
        city: '',
        state: '',
        zipCode: '',
        phoneNumber: '',
        website: '',
        rating: ''
    });
    const [categories, setCategories] = useState([]);

    useEffect(() => {
        if (isOpen && businessID) {
            fetchBusinessDetails();
            fetchCategories();
        }
    }, [isOpen, businessID]);

    const fetchBusinessDetails = async () => {
      try {
          const response = await getBusinessById(businessID);
          console.log("Fetched data:",response.data);
          setBusiness(response.data);
      } catch (error) {
          console.error('Error fetching business details:', error);
      }
  };
  
    const fetchCategories = async () => {
        try {
            const response = await getAllCategories();
            setCategories(response.data);
        } catch (error) {
            console.error('Error fetching categories:', error);
        }
    };

    const handleUpdateBusiness = async () => {
        try {
          console.log("updating")
          const updatedBusiness = { ...business };
          await updateBusiness(businessID, updatedBusiness);
          console.log("Business updated:", updatedBusiness); 
          toast.success("Business updated successfully!");
          console.log("toast should appear")
         onClose();
               }catch (error) {
            console.error('Error updating business:', error);
             toast.error("Failed to update business. Please try again.");
        }
    };

    if (!isOpen ) return null;

    return (
      
      <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-gray-300 px-4 py-2 w-2/5 rounded-lg shadow-lg">
      {/* <ToastContainer 
                position="top-right"
                autoClose={3000}
                hideProgressBar={false}
                closeOnClick
                pauseOnHover
                draggable
            /> */}
          <div className='flex justify-between'>
              <h2 className="text-xl font-bold mb-4">Edit Business</h2>
              <RxCrossCircled className='cursor-pointer text-3xl' onClick={onClose} />
          </div>
          <div className="grid grid-cols-3 items-center">
              <label className="text-xl">Business Name</label>
              <input type="text" className="col-span-2 border bg-gray-200 rounded-md px-2"
                  value={business.name} onChange={(e) => setBusiness({ ...business, name: e.target.value })} />
          </div>
          <div className="grid grid-cols-3 items-center">
              <label className="text-xl">Category</label>
              <select className='col-span-2 border bg-gray-200 rounded-md px-2' 
                  value={business.categoryID} 
                  onChange={(e) => setBusiness({ ...business, categoryID: e.target.value })}>
                  {categories.map(category => (
                      <option key={category.categoryID} value={category.categoryID}>{category.name}</option>
                  ))}
              </select>
          </div>
          <div className="grid grid-cols-3 items-center">
              <label className="text-xl">Address</label>
              <input type="text" className="col-span-2 border bg-gray-200 rounded-md px-2"
                  value={business.address} onChange={(e) => setBusiness({ ...business, address: e.target.value })} />
          </div>
          <div className="grid grid-cols-3 items-center">
              <label className="text-xl">City</label>
              <input type="text" className="col-span-2 border bg-gray-200 rounded-md px-2"
                  value={business.city} onChange={(e) => setBusiness({ ...business, city: e.target.value })} />
          </div>
          <div className="grid grid-cols-3 items-center">
              <label className="text-xl">State</label>
              <input type="text" className="col-span-2 border bg-gray-200 rounded-md px-2"
                  value={business.state} onChange={(e) => setBusiness({ ...business, state: e.target.value })} />
          </div>
          <div className="grid grid-cols-3 items-center">
              <label className="text-xl">Zip Code</label>
              <input type="text" className="col-span-2 border bg-gray-200 rounded-md px-2"
                  value={business.zipCode} onChange={(e) => setBusiness({ ...business, zipCode: e.target.value })} />
          </div>
          <div className="grid grid-cols-3 items-center">
              <label className="text-xl">Phone Number</label>
              <input type="text" className="col-span-2 border bg-gray-200 rounded-md px-2"
                  value={business.phoneNumber} onChange={(e) => setBusiness({ ...business, phoneNumber: e.target.value })} />
          </div>
          <div className="grid grid-cols-3 items-center">
              <label className="text-xl">Website</label>
              <input type="text" className="col-span-2 border bg-gray-200 rounded-md px-2"
                  value={business.website} onChange={(e) => setBusiness({ ...business, website: e.target.value })} />
          </div>
          <div className="grid grid-cols-3 items-center">
          <label className="text-xl">Rating </label>
                <input
                    type="number"
                    className="col-span-2 border bg-gray-200 rounded-md px-2"
                    value={business.rating}
                    onChange={(e) => {
                        let value = e.target.value;
                        if (value < 0) value = 0;
                        if (value > 5) value = 5;
                        setBusiness({ ...business, rating: value });
                    }}
                    min="0"
                    max="5"
                    step="0.1"
                />
                </div>
          <button className="bg-green-600 text-black font-semibold px-4 py-1 rounded-lg mt-4 hover:bg-green-800 hover:text-white"
              onClick={handleUpdateBusiness}>
              Update
          </button>
      </div>
  </div>
);
};

export default EditBusinessModal;
