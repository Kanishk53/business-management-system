import { NavLink } from "react-router-dom"
import React from "react"

const Leftbar = ()=>{
    
    
    return(
        <div className="w-52 h-[100vh] z-10 left-0 top-0 fixed  bg-gray-500">
            <nav className="mt-[100px]  flex flex-col items-center justify-center">
                <NavLink to='/' className={({isActive}) => `w-[75%]  p-2 m-2 border-inherit rounded-2xl  font-semibold  bg-white   ${isActive ? 'bg-white font-bold  text-gray-700':'text-white bg-opacity-20'}`}>Home</NavLink>

                <NavLink to='/businesses'  className={({isActive}) => `w-[75%]  p-2 m-2 border-inherit rounded-2xl font-semibold  bg-white   ${isActive ? 'bg-white font-bold  text-gray-700':'text-white bg-opacity-20'}`}>Businesses</NavLink>

                <NavLink to='/team' className={({isActive}) => `w-[75%]  p-2 m-2 border-inherit rounded-2xl font-semibold  bg-white   ${isActive ? 'bg-white font-bold  text-gray-700':'text-white bg-opacity-20'}`}>Team</NavLink>

                <NavLink to='/about' className={({isActive}) => `w-[75%]  p-2 m-2 border-inherit rounded-2xl font-semibold  bg-white   ${isActive ? 'bg-white font-bold  text-gray-700':'text-white bg-opacity-20'}`}>About Us</NavLink>
                
                
                
            </nav>
        </div>
    )
}
export default Leftbar