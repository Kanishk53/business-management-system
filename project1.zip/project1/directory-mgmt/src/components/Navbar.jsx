import React from 'react';
import { FaUserCircle } from "react-icons/fa";
import bdo from '../assets/bdo.png'

const Navbar = () => {
    return (
        <div className=' w-[100%] h-[90px] bg-gray-500 fixed top-0 left-0 z-20 flex  justify-between items-center bg-cover '>
        
        <div className='flex'>
         <img src={bdo} className="w-[160px] "></img><h2 className='text-red-600 font-bold mt-12'>INDIA</h2>
         </div>

            
            <FaUserCircle size={40} className="mr-8 " />
            </div>
        
    );
};
export default Navbar
